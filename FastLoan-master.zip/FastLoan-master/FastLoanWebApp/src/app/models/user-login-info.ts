export class UserLoginInfo {
    useremail?:string;
    password?:string;
    role?:string;
}
