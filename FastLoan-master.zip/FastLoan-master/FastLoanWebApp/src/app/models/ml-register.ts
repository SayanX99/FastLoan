export class MlRegister {
    email?: string;
    password?: string;   
    name?: string;
    mobileNo?: number;
    pan?:string;
}
