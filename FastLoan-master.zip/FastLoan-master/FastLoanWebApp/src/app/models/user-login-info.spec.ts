import { UserLoginInfo } from './user-login-info';

describe('UserLoginInfo', () => {
  it('should create an instance', () => {
    expect(new UserLoginInfo()).toBeTruthy();
  });
});
