import { Borrower } from './borrower';

describe('Borrower', () => {
  it('should create an instance', () => {
    expect(new Borrower()).toBeTruthy();
  });
});
