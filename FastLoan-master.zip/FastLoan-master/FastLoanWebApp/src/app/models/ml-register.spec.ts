import { MlRegister } from './ml-register';

describe('MlRegister', () => {
  it('should create an instance', () => {
    expect(new MlRegister()).toBeTruthy();
  });
});
