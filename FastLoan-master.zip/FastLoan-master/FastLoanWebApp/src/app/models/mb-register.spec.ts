import { MbRegister } from './mb-register';

describe('MbRegister', () => {
  it('should create an instance', () => {
    expect(new MbRegister()).toBeTruthy();
  });
});
