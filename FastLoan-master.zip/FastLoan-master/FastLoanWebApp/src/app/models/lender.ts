export class Lender {
    email: any;
    name?: string;
    pan?: string;
    mobileNo?: string;
    password?: string;
}
