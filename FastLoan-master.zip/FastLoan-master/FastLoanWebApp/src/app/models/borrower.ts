export class Borrower {
    email?: any;
    name?:string;
    pan?:string;
    mobileNo?:string;
    address?:string;
    password?:string;
    confirmPassword?:string;
    dob?:string;
    gender?:string;
    monthlyIncome?:string;
}
