import { ChatMessageDto } from './chat-message-dto';

describe('ChatMessageDto', () => {
  it('should create an instance', () => {
    expect(new ChatMessageDto()).toBeTruthy();
  });
});
