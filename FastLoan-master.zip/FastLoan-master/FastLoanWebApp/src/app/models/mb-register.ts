export class MbRegister {
    email?: string;
    password?:string;
    name?:string;
    pan?:string;
    mobileNo?:number;
    address?:string;
    monthlyIncome?:string;
    dob?:Date;
    gender?:string;
}
