export class Recommendation {
    
    loanOfferId:string='';
    loanType: string='';
    loanAmount: string='';
    timePeriod: string='';
    rateOfInterest: string='';
    createdDate: string='' ;
    lenderId: string='';
    lenderName: string='';
    
}
