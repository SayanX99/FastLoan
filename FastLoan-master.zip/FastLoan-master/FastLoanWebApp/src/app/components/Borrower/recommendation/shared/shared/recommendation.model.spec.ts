import { Recommendation } from './recommendation.model';

describe('Recommendation', () => {
  it('should create an instance', () => {
    expect(new Recommendation()).toBeTruthy();
  });
});
