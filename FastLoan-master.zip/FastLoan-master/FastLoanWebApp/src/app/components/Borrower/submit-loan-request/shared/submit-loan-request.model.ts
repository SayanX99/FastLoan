export class SubmitLoanRequest {
    LoanRequestId?:string;
    numberOfMonths?:string;
    sourceOfPay?:string;
    date?:string;
    loanOfferId?:string;
    lenderId?: string;
    BorrowerName?: string;
    BorrowerId?: string;
    lenderName?: string;
}
