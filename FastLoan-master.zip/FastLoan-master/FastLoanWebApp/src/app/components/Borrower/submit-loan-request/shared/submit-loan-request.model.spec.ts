import { SubmitLoanRequest } from './submit-loan-request.model';

describe('SubmitLoanRequest', () => {
  it('should create an instance', () => {
    expect(new SubmitLoanRequest()).toBeTruthy();
  });
});
