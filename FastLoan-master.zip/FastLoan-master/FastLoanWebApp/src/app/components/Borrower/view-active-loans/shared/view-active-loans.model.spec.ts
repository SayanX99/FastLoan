import { ViewActiveLoans } from './view-active-loans.model';

describe('ViewActiveLoans', () => {
  it('should create an instance', () => {
    expect(new ViewActiveLoans()).toBeTruthy();
  });
});
