export class ViewActiveLoans {
    
        loanOfferId?:string ;
        loanType?: string ;
        loanAmount?: string;
        timePeriod?: string;
        rateOfInterest?: string;
        createdDate?: string;
       borrowerId?:string;
        loanRequestId?:string;
        numberOfMonths?:string;
        sourceOfPay?:string;
        date?:string;
        lenderName?: string;
        lenderId?: string = '';
    
}
