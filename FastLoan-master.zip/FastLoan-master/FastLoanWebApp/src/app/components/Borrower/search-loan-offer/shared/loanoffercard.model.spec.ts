import { Loanoffercard } from './loanoffercard.model';

describe('Loanoffercard', () => {
  it('should create an instance', () => {
    expect(new Loanoffercard()).toBeTruthy();
  });
});
