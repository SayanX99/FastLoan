export class Loanoffercard {
    loanOfferId:string='';
    loanType: string='';
    loanAmount: string='';
    timePeriod: string='';
    rateOfInterest: string='';
    createdDate: string='' ;
    lenderId: string='';
    lenderName: string='';
   
}