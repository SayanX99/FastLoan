import { RequestedLoans } from './requested-loans.model';

describe('RequestedLoans', () => {
  it('should create an instance', () => {
    expect(new RequestedLoans()).toBeTruthy();
  });
});
