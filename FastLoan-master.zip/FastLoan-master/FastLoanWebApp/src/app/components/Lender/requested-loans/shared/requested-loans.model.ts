export class RequestedLoans {

    loanRequestId:string = '';
    numberOfMonths:string = '';
    sourceOfPay:string = '';
    date:string  = '';
    loanOfferId:string = '';
    lenderId: string = '';
    borrowerName: string = '';
    borrowerId: string = '';
    lenderName: string = '';
}
