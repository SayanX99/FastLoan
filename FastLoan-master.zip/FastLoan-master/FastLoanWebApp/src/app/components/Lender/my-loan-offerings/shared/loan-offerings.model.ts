export class LoanOfferings {
    
        loanOfferId: string='';
        loanType: string='';
        loanAmount: string='';
        timePeriod: string='';
        rateOfInterest: string='';
        createdDate: string='' ;
        lenderId: any;
    
}
