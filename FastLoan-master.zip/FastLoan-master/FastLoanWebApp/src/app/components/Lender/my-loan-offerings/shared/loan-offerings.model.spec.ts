import { LoanOfferings } from './loan-offerings.model';

describe('LoanOfferings', () => {
  it('should create an instance', () => {
    expect(new LoanOfferings()).toBeTruthy();
  });
});
