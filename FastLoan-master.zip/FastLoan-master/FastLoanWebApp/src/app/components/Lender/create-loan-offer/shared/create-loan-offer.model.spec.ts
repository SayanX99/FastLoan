import { CreateLoanOffer } from './create-loan-offer.model';

describe('CreateLoanOffer', () => {
  it('should create an instance', () => {
    expect(new CreateLoanOffer()).toBeTruthy();
  });
});
