
export class CreateLoanOffer {
    loanOfferId: any;
    loanType: string = '';
    loanAmount: string = '';
    timePeriod: string = '';
    rateOfInterest: string = '';
    createdDate: string = '' ;
    lenderName: any;
    lenderId?: any;
}
