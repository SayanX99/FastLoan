import { ActiveLoans } from './active-loans.model';

describe('ActiveLoans', () => {
  it('should create an instance', () => {
    expect(new ActiveLoans()).toBeTruthy();
  });
});
