﻿namespace UserService.Models
{
    public class UserDto
    {
        public string? UserEmail { get; set; }
        public string? Password { get; set; }
        public string? Role { get; set; }
    }
}
