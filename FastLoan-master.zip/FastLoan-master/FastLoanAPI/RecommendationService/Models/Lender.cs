﻿namespace FastLoan.Models
{
    public class Lender
    {
        public string?  LenderId { get; set; }
        public string LenderName { get; set; }= default!;  
       
        
    }
}
