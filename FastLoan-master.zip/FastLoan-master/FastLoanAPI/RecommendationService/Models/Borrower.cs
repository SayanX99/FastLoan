﻿namespace FastLoan.Models
{
    public class Borrower
    {
        public string? BorrowerId { get; set; }
        public string? BorrowerName { get; set; }
    }
}
